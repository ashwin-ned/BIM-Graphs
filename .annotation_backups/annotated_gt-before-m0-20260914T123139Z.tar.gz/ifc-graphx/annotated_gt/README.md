# Imported annotation ground truth

The canonical human verdicts are in `../annotations/bimsg-annotations__AN.json`. They preserve negative verdicts, uncertain judgments, labels, notes, additions and missing-room pins. New-bundle entries take precedence over older entries for the same model/annotator; older buildings absent from the new bundle are retained.

Top-level graph/GT files have complete verdict coverage of the existing plans. Partial exports are in `incomplete/` and retain `complete: false`. See `_summary.json` for per-building counts and unresolved work. Completeness does not mean all missing rooms, merge requests or held-out items have been resolved. Do not automatically use every exported building as an exhaustive benchmark.

The `.gt.json` files retain the existing positive-pair export format. They are not a replacement for the canonical verdict bundle when scoring negative or unknown cases; the legacy synthetic evaluator still requires a real-data adapter, as documented in the codebase audit.

Regenerate the complete exports from the workspace root with:

```bash
/mnt/data/home/anedung/miniforge3/envs/bim-sg/bin/python ifc-graphx/annotator/build_gt.py --inbox ifc-graphx/annotations --out ifc-graphx/annotated_gt
```

The import manifest contains additional coverage and source-hash information beyond the legacy builder summary.
